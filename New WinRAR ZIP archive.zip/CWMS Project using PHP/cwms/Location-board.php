<?php error_reporting(0);
include('includes/config.php');
session_start();


//initialize cart if not set or is unset
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Raia Media | Home Page</title>


    <!-- Favicon -->
    <link href="img/raialogo.jpg" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Top Bar Start -->
    <?php include_once('includes/header1.php'); ?>


    <!-- Page Header Start -->
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Billboard Location</h2>
                </div>
                <div class="col-12">
                    <a href="index.php">Home</a>
                    <a href="location.php">Amman</a>
                    <a href="location.php">AlZarqa</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Location Start -->
    <div class="location">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-header text-left">
                        <p>Billboard Location</p>
                        <h2>Amman</h2>
                    </div>
                    <div class="row">
                        <?php $sql = "SELECT * from location";
                        $query = $dbh->prepare($sql);
                        $query->execute();
                        $results = $query->fetchAll(PDO::FETCH_OBJ);
                        foreach ($results as $result) { ?>
                            <div class="about">
                                <div class="container">
                                    <div class="row align-items-center">
                                        <div class="col-lg-6">
                                            <div class="carousel slide" data-ride="carousel">
                                                <div class="container-inner">
                                                    <div class="owl-carousel">
                                                        <?php $sql = "SELECT * from photos where location_id = ($result->location_ide)";
                                                        $query = $dbh->prepare($sql);
                                                        $query->execute();
                                                        $results = $query->fetchAll(PDO::FETCH_OBJ);

                                                        foreach ($results as $result2) { ?>
                                                            <div class="carousel-item">
                                                                <?php {
                                                                    echo '<img src="data:image/png;base64,' . base64_encode($result2->photo_location) . '" />';
                                                                }
                                                                ?>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="section-header text-left">

                                                <h4>Wall Unit : <?php echo htmlentities($result->location_name); ?></h4>
                                                <br />
                                                <h4>Size : <?php echo htmlentities($result->location_size); ?></h4>
                                                <br />
                                                <h4><a href="https://www.google.com/maps/@31.9740495,35.8655992,3a,55.8y,68.98h,107.44t/data=!3m6!1e1!3m4!1sZXghWhxpWm63kjdQ50ej3g!2e0!7i13312!8i6656">Location </a>: <?php echo htmlentities($result->location_coordinates); ?></h4>
                                                <br />
                                                <h4>
                                                    <?php
                                                    if (($result->location_availability) == true) {
                                                        echo '
                                <i class="fa fa-check-circle"style="color: #39B972"></i> Available 
                                ';
                                                    } else {
                                                        echo '
                                <i class="far fa-times-circle"style="color:#E81C2E"></i> Unavailable Until : 
                                 ';
                                                        echo htmlentities($result->location_available_details);
                                                    } ?>
                                                </h4>
                                                <br />
                                                <h4>Price : <?php echo (number_format($result->location_price)); ?> JD's/Month</h4>
                                                <input type="hidden" name="hidden_name" value="<?php echo ($result->location_name); ?>" />
 
                                                 <input type="hidden" name="hidden_price" value="<?php echo (number_format($result->location_price)); ?>" />
                                                 <a class="btn btn-custom" href="add_cart.php?id=<?php echo ($result->location_ide); ?>">Add to Cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>

                </div>
            </div>

        </div>
    </div>
  <?php 
   $MAC = exec('getmac');
   $MAC = strtok($MAC, ' ');
       echo $MAC;
   
?>
    <!-- Location End -->
    <?php include_once('includes/footer.php'); ?>



    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>